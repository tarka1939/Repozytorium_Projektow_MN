from MACD_implementation import MACD
from graphing import plot_simulation
import pandas as pd
def simulation(starting_capital, data, macd):
    #use macd to simulate buying and selling of stock
    #buy when macd crosses signal line from below
    #sell when macd crosses signal line from above
    #initialise variables
    capital = starting_capital
    stock = 0
    #simulation constants
    percent_bought = 100
    percent_sold = 100
    
    #iterate through data
    simulation = []
    for i in range(1, len(macd)):
        if macd[i][0] == 1:
            #buy stock
            stock = stock + capital*percent_bought/100/ data['Open'][i]
            capital = capital - capital*percent_bought/100
        elif macd[i][0] == -1:
            #sell stock
            capital = capital + stock*percent_sold/100*data['Open'][i]
            stock = stock - stock*percent_sold/100
        stock_value = stock * data['Close'][i]
        simulation.append([capital,stock_value, capital + stock_value])    
    plot_simulation(simulation)
    return capital