import pandas as pd
import numpy as np
import graphing as graph
import simulation as sim
import MACD_implementation as macd
# Read data from file
import pandas as pd
#import data from date X to date Y
X = '2021-01-01'
Y = '2026-01-01'
data = pd.read_csv('data.csv')
data = data.set_index('Date')
data.index = pd.to_datetime(data.index)
data = data.loc[X:Y]
data.index.name = 'Date'
data.shape
data.head(3)
data.tail(3)
#graph data
graph.graph_data(data)
macd, diff, signal = macd.MACD(data, 12, 26, 9)
#graph the macd
graph.plot_MACD(macd, diff, signal, data)
#start the simulation

capital = sim.simulation(10000, data, macd)
print(capital)
